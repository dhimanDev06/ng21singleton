import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ApiObject {
  id: string;
  userId: string;
  title: string;
  body: string;
}

@Injectable({ providedIn: 'root' })
export class ApiService {
  private baseUrl = 'https://jsonplaceholder.typicode.com/';

  constructor(private http: HttpClient) {}

  // GET all objects
  getAllObjects(): Observable<ApiObject[]> {
    return this.http.get<ApiObject[]>(this.baseUrl+'/posts');
  }

  // GET single object by id
  getObject(id: string): Observable<ApiObject> {
    return this.http.get<ApiObject>(`${this.baseUrl}/posts/${id}`);
  }
}
