import { Component, OnInit } from '@angular/core';
import { ApiObject, ApiService } from '../../services/api';

@Component({
  selector: 'app-home',
  imports: [],
  templateUrl: './home.html',
  styleUrl: './home.scss',
})
export class Home implements OnInit {
   objects: ApiObject[] = [];
isLoading = true;
   constructor(private api: ApiService) {}
  ngOnInit(): void {
        this.api.getAllObjects().subscribe({
      next: (data) => {
        this.objects = data
        this.isLoading = false;
        console.log('Objects loaded:'+this.isLoading, this.objects);},
      error: (err) => console.error('Error loading objects:', err),
    });
    console.log('Home component initialized',this.objects);
  }

}
